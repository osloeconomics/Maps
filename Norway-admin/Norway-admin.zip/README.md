N2000-Kartdata
==============

Improved version of N2000 Kartdata.

More information about this dataset on thematic mapping blog: <a href="http://blog.thematicmapping.org/2013/06/merging-polygons-in-qgis.html">part 1</a>, <a href="http://blog.thematicmapping.org/2013/06/splitting-and-clipping-shapefiles-with.html">part 2</a>.

© Kartverket
